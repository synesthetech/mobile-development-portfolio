package com.snhu.project;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.snhu.project.EventDatabaseHelper;
import android.widget.Button;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    private EventDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        dbHelper = new EventDatabaseHelper(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.homeGridLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (getIntent().getBooleanExtra("showConfirmation", false)) {
            showConfirmation();
        }

        Button smsButton = findViewById(R.id.smsButton);

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SmsSignupActivity.class);
                startActivity(intent);

            }
        });
    }
    private void showConfirmation() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setMessage("SMS notifications enabled!")
                .setPositiveButton("OK", (dialog, id) -> {

                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

}