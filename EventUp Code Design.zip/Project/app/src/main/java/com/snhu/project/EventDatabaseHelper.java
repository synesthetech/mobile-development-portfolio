package com.snhu.project;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

public class EventDatabaseHelper  extends SQLiteOpenHelper {

        private static final String DATABASE_NAME = "events.db";
        private static final int VERSION = 1;


        public EventDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, VERSION);

        }

        private static final class EventTable {
            private static final String TABLE = "events";
            private static final String COL_ID = "_id";
            private static final String COL_NAME = "name";
            private static final String COL_DATE = "date";
            private static final String COL_INFO = "info";
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table " + EventTable.TABLE + " (" +
                    EventTable.COL_ID + " integer primary key autoincrement, " +
                    EventTable.COL_NAME + " text, " +
                    EventTable.COL_DATE + " text, " +
                    EventTable.COL_INFO + " text) ");
        }

        public long addEvent() {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(EventTable.COL_NAME, "Red Velvet Concert");
            values.put(EventTable.COL_DATE, "04/19/2024 17:00:00");
            values.put(EventTable.COL_INFO, "Event info describing the concert");
            return db.insert(EventTable.TABLE, null, values);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,
                              int newVersion) {
            db.execSQL("drop table if exists " + EventTable.TABLE);
            onCreate(db);
        }
}
